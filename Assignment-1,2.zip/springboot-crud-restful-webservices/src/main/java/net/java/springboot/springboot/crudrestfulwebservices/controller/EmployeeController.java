package net.java.springboot.springboot.crudrestfulwebservices.controller;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import net.java.springboot.springboot.crudrestfulwebservices.exception.ResourceNotFoundException;
import net.java.springboot.springboot.crudrestfulwebservices.model.Employee;
import net.java.springboot.springboot.crudrestfulwebservices.repository.EmployeeRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;

import java.util.List;

@RestController
@RequestMapping("/api/v1")
public class EmployeeController {
	@Autowired
	private EmployeeRepository employeeRepository;

	// create get all employees api
	@GetMapping("/employees")
	public List<Employee> getAllEmployees() {
		return employeeRepository.findAll();

	}

	// create employee
	@PostMapping("/employees")
	public Employee createEmployee(@Valid @RequestBody Employee employee) {
		return employeeRepository.save(employee);
	}

	// get employee by UserId
	@GetMapping("/employees/{UserId}")
	public ResponseEntity<Employee> getEmployeeById(@PathVariable(value = "UserId") long employeeUserId)
			throws ResourceNotFoundException {
		Employee employee = employeeRepository.findById(employeeUserId)
				.orElseThrow(() -> new ResourceNotFoundException("Employee not found for this ::" + employeeUserId));
		return ResponseEntity.ok().body(employee);
	}

	// update employee

	@PutMapping("employees/{UserId}")
	public ResponseEntity<Employee> updateEmployee(@PathVariable(value = "UserId") long employeeUserId,
			@RequestBody Employee employeeDetails) throws ResourceNotFoundException {
		Employee employee = employeeRepository.findById(employeeUserId)
				.orElseThrow(() -> new ResourceNotFoundException("Employee not found for this ::" + employeeUserId));
		employee.setFirstName(employeeDetails.getFirstName());
		employee.setLastName(employeeDetails.getLastName());
		employee.setMobileNumber(employeeDetails.getMobileNumber());
		employee.setAddress(employeeDetails.getAddress());
		employee.setDepartment(employeeDetails.getDepartment());
		employeeRepository.save(employee);
		return ResponseEntity.ok().body(employee);

	}

	// delete employee by UserId

	@DeleteMapping("/employees/{UserId}")
	public ResponseEntity<?> deleteEmployee(@PathVariable(value = "UserId") long employeeUserId)
			throws ResourceNotFoundException {
		employeeRepository.findById(employeeUserId)
				.orElseThrow(() -> new ResourceNotFoundException("Employee not found for this ::" + employeeUserId));

		employeeRepository.deleteById(employeeUserId);
		return ResponseEntity.ok().build();
	}
}
