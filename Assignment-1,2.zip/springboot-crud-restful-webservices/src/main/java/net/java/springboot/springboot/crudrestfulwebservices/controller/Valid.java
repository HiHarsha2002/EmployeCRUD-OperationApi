package net.java.springboot.springboot.crudrestfulwebservices.controller;

public @interface Valid {

}
