import java.util.Arrays;
import java.util.List;
public class AverageOfListIntegers {
    
    //function to Average List of Integers
    private static double calculateAverage(List <Integer> marks) {
        if (marks == null || marks.isEmpty()) {
            return 0;
        }
    
        double sum = 0;
        for (Integer mark : marks) {
            sum += mark;
        }
    
        return sum / marks.size();
        }
        public static void main(String[] args) {
            List<Integer> list = Arrays.asList(1, 2, 3, 4, 5);
            double avg = calculateAverage(list);
            System.out.println(avg);        // 3.0
        }
}
